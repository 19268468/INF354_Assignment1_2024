﻿using Architecture_API.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore.Query.Internal;

namespace Architecture_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {

        private readonly AppDbContext _courseRepository; //AppDbCOntext is the name of the DbCOntext

        public CourseController(AppDbContext courseRepository)
        {
            _courseRepository = courseRepository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Course>>> GetCourses()
        {
            return Ok(await _courseRepository.Courses.ToListAsync());
        }

        [HttpPost]
        public async Task<ActionResult<List<Course>>> CreateCourse(Course course)
        {
            _courseRepository.Courses.Add(course);
            await _courseRepository.SaveChangesAsync();
            
            return Ok(await _courseRepository.Courses.ToListAsync());
        }

        [HttpPut]
        public async Task<ActionResult<List<Course>>> UpdateCourse(Course course)
        {
            var dbCourse = await _courseRepository.Courses.FindAsync(course.CourseId);
            if (dbCourse == null)
            
                return BadRequest("Course not found.");
            
            dbCourse.Name = course.Name;
            dbCourse.Duration = course.Duration;
            dbCourse.Description = course.Description;

            await _courseRepository.SaveChangesAsync();

            return Ok(await _courseRepository.Courses.ToListAsync());
        }

        [HttpDelete("{id}")]
        public async Task <ActionResult<List<Course>>> DeleteCourse (int id)
        {
            var dbCourse = await _courseRepository.Courses.FindAsync(id);
            if (dbCourse == null)
                return BadRequest("Course not found.");

            _courseRepository.Courses.Remove(dbCourse);
            await _courseRepository.SaveChangesAsync();

            return Ok(await _courseRepository.Courses.ToListAsync());
        }
    }
}
