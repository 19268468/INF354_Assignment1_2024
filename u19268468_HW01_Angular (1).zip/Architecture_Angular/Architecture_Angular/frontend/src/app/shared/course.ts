export interface Course {
    courseId?: number;
    name:"";
    duration:"";
    description:"";
}