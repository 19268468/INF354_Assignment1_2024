import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CoursesComponent } from './course/courses/courses.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'frontend';
  router: any;

  constructor(private _dialog: MatDialog) {
 
  }  

  

  openAddCourseDialog() {
    this._dialog.open(CoursesComponent);
  }

  
}
function clickButton(path: any, string: any) {
  throw new Error('Function not implemented.');
}

