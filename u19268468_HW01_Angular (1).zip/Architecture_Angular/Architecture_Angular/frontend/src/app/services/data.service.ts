import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, Subject } from 'rxjs';
import { environment } from '../../environments/environment';
import { CoursesComponent } from '../course/courses/courses.component';
import { Course } from '../shared/course';
import { EditCourseComponent } from '../components/edit-course/edit-course.component';
import { AddCourseComponent } from '../add-course/add-course.component';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private url = "Course";
  apiUrl = 'https://localhost:7049/api/'

  httpOptions ={
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  }

  constructor(private httpClient: HttpClient) { }

  // GetCourses(): Observable<any>{
  //   return this.httpClient.get<any>(`${this.apiUrl}Course/GetAllCourses`)
  //   .pipe(map(result => result))
  // }

  // updateCourse(course: Course): Observable<any>{
  //   return this.httpClient.put<any>(`${this.apiUrl}Course/GetAllCourses`)
  //   .pipe(map(result => result))
  // }

  public GetCourses(): Observable<any> {
    return this.httpClient.get<any>(`${environment.apiUrl}/${this.url}/GetAllCourses`);
  }

  public updateCourse(course: CoursesComponent): Observable<any> {
    return this.httpClient.put<any>(`${environment.apiUrl}/${this.url}`,course);
  }

  public createCourse(course: CoursesComponent): Observable<any> {
    return this.httpClient.post<any>(`${environment.apiUrl}/${this.url}`,course);
  }

  public deleteCourse(course: CoursesComponent): Observable<any> {
    return this.httpClient.delete<any>
    (`${environment.apiUrl}/${this.url}/${course.course?.courseId}`);
  }
  //public deleteCourse(course: Course)
}


