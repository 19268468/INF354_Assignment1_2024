import { Component , EventEmitter, Input, OnInit, Output} from '@angular/core';
import { Course } from '../../shared/course';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-edit-course',
  templateUrl: './edit-course.component.html',
  styleUrl: './edit-course.component.scss'
})

export class EditCourseComponent implements OnInit{
  @Input() course?: Course;
  @Output() coursesUpdated = new EventEmitter<Course[]>();

  title = 'Architecture_Angular'
  courses: Course[] = [];
  courseToEdit?: Course;

 

    ngOnInit(): void {}

  updateCourse(course: Course) {
    this.coursesUpdated.subscribe((courses: Course[]) => 
    (this.courses = courses));
   
    //.updateCourse(course)
    //.subscribe((courses: Course[])=> this.coursesUpdated.emit(courses));
  }

  
  

}
