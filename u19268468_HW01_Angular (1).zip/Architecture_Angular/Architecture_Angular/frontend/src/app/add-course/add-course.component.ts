import { Component, Input } from '@angular/core';
import { Course } from '../shared/course';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrl: './add-course.component.scss'
})
export class AddCourseComponent {
  title = 'Architecture_Angular';
  courses: Course[] = [];
  courseToEdit?: Course;

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.GetCourse();
    console.log(this.courses);
  }

    createCourse(course: Course) {
    this.dataService
   .GetCourse()
   .subscribe((courses: Course[]) => this.courses = courses);
   }



  initNewCourse() {
    
  }
}
