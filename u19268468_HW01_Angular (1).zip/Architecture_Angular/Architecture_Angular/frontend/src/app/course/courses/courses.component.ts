import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Course } from '../../shared/course';
import { DataService } from '../../services/data.service';



@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.scss']
})

export class CoursesComponent implements OnInit {
  title= 'Architecture_Angular';
  courses:Course[] = []

  @Input() course?: Course;
  @Output() coursesUpdated = new EventEmitter<Course[]>();

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.GetCourses()
    //.subscribe((result: Course[]) => (this.courses = result));
    console.log(this.courses)
  }

  GetCourses()
  {
    this.dataService.GetCourses().subscribe(result => {
      let courseList:any[] = result
      courseList.forEach((element) => {
        this.courses.push(element)
      });
    })

    
     deleteCourse( courseId?: number) { 
         this.dataService
         .deleteCourse(course)
         .subscribe((courses: Course[]) => this.coursesUpdated.emit(courses));
     }
  }
}
