export const environment = {
    produvtion: false,
    apiUrl: 'https://localhost:7049/api/Course/GetAllCourses'
};